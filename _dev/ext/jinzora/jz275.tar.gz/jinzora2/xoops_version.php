<?php
$modversion['name'] = "Jinzora";
$modversion['version'] = 2.5;
$modversion['description'] = "A complete web-based multimedia streamer.";
$modversion['credits'] = "Ross Carlson, Ben Dodson";
$modversion['author'] = "Ross Carlson, Ben Dodson";
$modversion['help'] = "http://www.jinzorahelp.com";
$modversion['license'] = "GPLv2";
$modversion['official'] = 0;
$modversion['image'] = "style/asx-banner.gif";
$modversion['dirname'] = "jinzora2";
$modversion['hasAdmin'] = 0;
$modversion['adminmenu'] = '';
$modversion['hasMain'] = 1;
?>