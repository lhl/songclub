<?php 

function com_uninstall()
{
	return "uninstalled";
}

?>