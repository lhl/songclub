<?php // define('JZ_SECURE_ACCESS','true');
	$_SERVER['cms_type'] = "mambo";
	include_once('components/com_jinzora/index.php');
?>