<?php
$jbArr[0]['server'] = 'localhost';
$jbArr[0]['port'] = '6600';
$jbArr[0]['description'] = 'MPD Player';
$jbArr[0]['password'] = '';
$jbArr[0]['type'] = 'mpd';
?>