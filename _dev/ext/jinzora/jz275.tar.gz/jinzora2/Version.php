<?php 
$modversion['name'] = 'Jinzora';
$modversion['version'] = '2.x';
$modversion['description'] = 'Jinzora Media Jukebox';
$modversion['credits'] = '';
$modversion['help'] = '';
$modversion['changelog'] = '';
$modversion['license'] = '';
$modversion['official'] = 0;
$modversion['author'] = 'Ross Carlson, Ben Dodson';
$modversion['contact'] = 'http://www.jinzora.org';
$modversion['admin'] = 0;
//$modversion['securityschema'] = array('Jinzora::' => '::');

?>