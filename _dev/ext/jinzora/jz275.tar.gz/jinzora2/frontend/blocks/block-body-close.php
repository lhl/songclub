<?php
	$display = new jzDisplay();
	$smarty = smartySetup();
        jzTemplate($smarty, "block-body-close");
?>