<?php
	$display = new jzDisplay();
	$smarty = smartySetup();
        jzTemplate($smarty, "block-spacer");
?>