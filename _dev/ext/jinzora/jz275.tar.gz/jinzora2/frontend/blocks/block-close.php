<?php
	jzTemplate($smarty, "block-close");
?>