<?php
	jzTemplate($smarty, "block-open");
?>