<?php 
	if (!defined(JZ_SECURE_ACCESS)) die ('Security breach detected.');	
	require_once($include_path. 'frontend/frontends/slick/genre.php');		
?>