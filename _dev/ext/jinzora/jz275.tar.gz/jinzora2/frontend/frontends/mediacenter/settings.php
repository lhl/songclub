<?php if (!defined(JZ_SECURE_ACCESS)) die ('Security breach detected.');
	$show_images = "true";			//Should we show album art?
	$image_size = "120";			//What dimensions should the art be "120x120"
	$desc_truncate = "500";			//How long should the descriptions be
	$show_artist_album = "true";		//Should we show the artist/album info on the tracks page
	$show_track_num = "true";			//Show the track numbers on the album pages
	$allow_interface_change = "true"; //Should we show the interface changer
	$show_frontpage_items = "true";
	$show_artist_alpha = "false";
	$show_artist_list = "true";
	$allow_theme_change = "true";
?>
