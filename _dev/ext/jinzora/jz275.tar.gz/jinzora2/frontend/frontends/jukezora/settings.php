<?php 
	if (!defined(JZ_SECURE_ACCESS)) die ('Security breach detected.');

	$advanced_tooltips = "true";
?>