<?php if (!defined(JZ_SECURE_ACCESS)) die ('Security breach detected.');
	$show_slimzora = "true";
	$allow_style_choice = "true";
	$allow_interface_choice = "true";
	$max_song_name_length = "20";
	$truncate_artist_description = "800";
?>