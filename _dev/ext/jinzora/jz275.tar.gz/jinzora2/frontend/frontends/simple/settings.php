<?php if (!defined(JZ_SECURE_ACCESS)) die ('Security breach detected.');
	$show_track_num = "false";			//Show the track numbers on the album pages
	$allow_interface_change = "true"; //Should we show the interface changer
	$show_artist_alpha = "false";
	$show_full_footer = "false";
	$truncate_length = "20";
?>