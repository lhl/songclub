<?php if (!defined(JZ_SECURE_ACCESS)) die ('Security breach detected.');
$show_images = "true";
$show_descriptions = "true";
$force_resample = "false";
$default_resample = "48";
$item_truncate = "25";
?>