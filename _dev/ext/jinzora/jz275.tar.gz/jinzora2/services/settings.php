<?php if (!defined(JZ_SECURE_ACCESS)) die ('Security breach detected.');
$service_lyrics = "jinzora";
$service_similar = "echocloud";
$service_link = "google";
$service_metadata = "jinzora";
$service_tagdata = "getid3";
$service_images = "gd2";
$service_cdburning = "cdrecord";
$service_shopping = "amazon";
$service_shopping_amazon_id = "jinzora-20";
?>