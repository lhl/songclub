		/* * * * * * * * * * * * * * * * * * *
		 *            Overrides              *
		 * * * * * * * * * * * * * * * * * * */
		// TO ADD: getMainArt(), getDescription()
		// Then change to the directory called backend and run 'php global_include.php' to add the changes.
