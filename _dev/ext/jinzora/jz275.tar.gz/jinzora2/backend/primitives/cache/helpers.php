<?php if (!defined(JZ_SECURE_ACCESS)) die ('Security breach detected.');
	// Some constants:
	$unit_space = "  ";
	$meta_line_count = "3";

?>
