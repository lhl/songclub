"""Resolving Internet Names"""
